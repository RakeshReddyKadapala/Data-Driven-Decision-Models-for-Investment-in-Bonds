# project-bonds
Finding the best investment between Gold Bonds and General Bonds by building a forecasting model.
